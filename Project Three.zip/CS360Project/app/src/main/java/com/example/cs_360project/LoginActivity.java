package com.example.cs_360project;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Database helper instance for interacting with the user database
    Databasehelper dbHelper;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Enable edge-to-edge display and set the layout for this activity
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // Reference input fields and buttons from the layout
        EditText usernameEditText = findViewById(R.id.username);
        EditText passwordEditText = findViewById(R.id.password);
        Button loginButton = findViewById(R.id.login_button);
        Button registerButton = findViewById(R.id.register_button);

        // Initialize the database helper
        dbHelper = new Databasehelper(this);

        // Set up onClick listener for the login button
        loginButton.setOnClickListener(v -> {
            // Retrieve user input from the text fields
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Check if the user credentials are valid
            if (dbHelper.checkUser(username, password)) {
                Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                // Start the main activity upon successful login
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();  // Close LoginActivity so it can't be accessed with the back button
            } else {
                // Display an error message for invalid credentials
                Toast.makeText(LoginActivity.this, "Invalid credentials", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up onClick listener for the register button
        registerButton.setOnClickListener(v -> {
            // Retrieve user input for registration
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Attempt to add the new user to the database
            if (dbHelper.addUser(username, password)) {
                Toast.makeText(LoginActivity.this, "User registered", Toast.LENGTH_SHORT).show();
            } else { // Display an error message if registration fails
                Toast.makeText(LoginActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
            }
        });
    }
}