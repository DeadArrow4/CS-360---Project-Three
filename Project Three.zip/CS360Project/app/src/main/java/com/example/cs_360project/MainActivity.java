package com.example.cs_360project;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    private static final int SMS_PERMISSION_CODE = 101;

    Databasehelper dbHelper;
    GridView gridView;
    ArrayList<String> dataList;
    ArrayAdapter<String> adapter;
    private int selectedEntryId = -1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Check and request SMS permission if not already granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }


        // Initialize UI elements and variables
        gridView = findViewById(R.id.grid_view);
        dbHelper = new Databasehelper(this);
        dataList = new ArrayList<>();

        // Load initial data from the database
        loadData();

        // Set click listeners for buttons
        findViewById(R.id.button_add).setOnClickListener(view -> showAddDataDialog());
        findViewById(R.id.button_update).setOnClickListener(view -> showUpdateDataDialog());
        findViewById(R.id.button_delete).setOnClickListener(view -> showDeleteDataDialog());

        // Set item click listener on GridView to select an entry and get its ID
        gridView.setOnItemClickListener((adapterView, view, position, id) -> {
            String selectedEntry = dataList.get(position);
            selectedEntryId = Integer.parseInt(selectedEntry.split("\\|")[0]); // Get entry ID
            Toast.makeText(this, "Selected entry for deletion: " + selectedEntryId, Toast.LENGTH_SHORT).show();
        });
    }
    // Load data from database
    private void loadData() {
        Cursor cursor = dbHelper.getAllWeights();
        dataList.clear();

        // Ensure columns exist before attempting to access them
        int idIndex = cursor.getColumnIndex("id");
        int dateIndex = cursor.getColumnIndex("date");
        int weightIndex = cursor.getColumnIndex("weight_value");
        int lossGainIndex = cursor.getColumnIndex("loss_gain_ratio");
        int goalWeightIndex = cursor.getColumnIndex("goal_weight");
        if (dateIndex == -1 || weightIndex == -1 || lossGainIndex == -1 || goalWeightIndex == -1) {
            Toast.makeText(this, "Database columns missing", Toast.LENGTH_SHORT).show();
            cursor.close();
            return;
        }

        // Populate dataList with values
        while (cursor.moveToNext()) {
            int id = cursor.getInt(idIndex);
            String date = cursor.getString(dateIndex);
            double weight = cursor.getDouble(weightIndex);
            double lossGain = cursor.getDouble(lossGainIndex);
            double goalWeight = cursor.getDouble(goalWeightIndex);


            dataList.add(id + "|" + "Date: " + date +
                    ", Weight: " + weight +
                    ", Loss/Gain: " + lossGain +
                    ", Goal: " + goalWeight);
        }
        cursor.close();

        // Bind data to GridView using ArrayAdapter
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, dataList);
        gridView.setAdapter(adapter);
    }

    // Show dialog for adding new data entry
    private void showAddDataDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_data, null);

        // Input fields for new entry data
        EditText inputDate = dialogView.findViewById(R.id.input_date);
        EditText inputWeight = dialogView.findViewById(R.id.input_weight);
        EditText inputLossGain = dialogView.findViewById(R.id.input_loss_gain);
        EditText inputGoalWeight = dialogView.findViewById(R.id.input_goal_weight);

        // Set dialog layout and add button actions
        builder.setView(dialogView)
                .setTitle("Add Weight Entry")
                .setPositiveButton("Add", (dialog, which) -> {
                    String date = inputDate.getText().toString();
                    double weight = Double.parseDouble(inputWeight.getText().toString());
                    double lossGain = Double.parseDouble(inputLossGain.getText().toString());
                    double goalWeight = Double.parseDouble(inputGoalWeight.getText().toString());
                    dbHelper.addWeightEntry(date, weight, lossGain, goalWeight);
                    loadData();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Show dialog for updating an existing entry
    private void showUpdateDataDialog() {
        if (selectedEntryId == -1) {
            Toast.makeText(this, "No entry selected for update", Toast.LENGTH_SHORT).show();
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_data, null);

        // Input fields for updating entry data
        EditText inputDate = dialogView.findViewById(R.id.input_date);
        EditText inputWeight = dialogView.findViewById(R.id.input_weight);
        EditText inputLossGain = dialogView.findViewById(R.id.input_loss_gain);
        EditText inputGoalWeight = dialogView.findViewById(R.id.input_goal_weight);

        // Set dialog layout and update button actions
        builder.setView(dialogView)
                .setTitle("Update Weight Entry")
                .setPositiveButton("Update", (dialog, which) -> {
                    String date = inputDate.getText().toString();
                    double weight = Double.parseDouble(inputWeight.getText().toString());
                    double lossGain = Double.parseDouble(inputLossGain.getText().toString());
                    double goalWeight = Double.parseDouble(inputGoalWeight.getText().toString());
                    dbHelper.updateWeightEntry(selectedEntryId, date, weight, lossGain, goalWeight);
                    loadData();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    // Show dialog for deleting a selected entry
    private void showDeleteDataDialog() {
        if (selectedEntryId == -1) {
            Toast.makeText(this, "No entry selected for deletion", Toast.LENGTH_SHORT).show();
            return;
        }

        // Confirm deletion dialog
        new AlertDialog.Builder(this)
                .setTitle("Delete Entry")
                .setMessage("Are you sure you want to delete this entry?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    dbHelper.deleteWeightEntry(selectedEntryId);
                    selectedEntryId = -1; // Reset selection
                    loadData();
                })
                .setNegativeButton("No", null)
                .show();
    }

    // Handle SMS permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, send SMS
                sendSMS();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Send SMS notification (placeholder method)
    private void sendSMS() {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage("phoneNo", null, "Notification text", null, null);
    }
}