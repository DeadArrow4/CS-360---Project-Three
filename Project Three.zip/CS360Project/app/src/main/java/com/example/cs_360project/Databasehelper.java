package com.example.cs_360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Databasehelper extends SQLiteOpenHelper {
    // Database and table names
    private static final String DATABASE_NAME = "user_db";
    private static final String TABLE_USERS = "users";
    private static final String TABLE_WEIGHT = "weight";

    // User table columns
    private static final String COL_ID = "id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Weight table columns
    private static final String COL_WEIGHT_ID = "id";
    private static final String COL_WEIGHT_VALUE = "weight_value";
    private static final String COL_DATE = "date";
    private static final String COL_LOSS_GAIN_RATIO = "loss_gain_ratio";
    private static final String COL_GOAL_WEIGHT = "goal_weight";

    // Constructor initializes the database
    public Databasehelper(Context context) {
        super(context, "user_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL statement to create user table
        String createTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createTable);

        // SQL statement to create weight table
        String createWeightTable = "CREATE TABLE " + TABLE_WEIGHT + " (" +
                COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_WEIGHT_VALUE + " REAL, " +
                COL_DATE + " TEXT, " +
                COL_LOSS_GAIN_RATIO + " REAL, " +
                COL_GOAL_WEIGHT + " REAL)";
        db.execSQL(createWeightTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if they exist and recreate them
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHT);
        onCreate(db);
    }

    // Method to add a new user to the database
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_USERNAME, username);
        contentValues.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, contentValues);
        return result != -1; // Returns true if insertion was successful
    }

    // Method to check if user credentials are valid
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password}, null, null, null);
        return cursor.getCount() > 0; // Returns true if user exists

    }

    // Method to retrieve all weight entries from the weight table
    public Cursor getAllWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_WEIGHT, null);
    }

    // Add weight entry method
    public boolean addWeightEntry(String date, double weight, double lossGainRatio, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DATE, date);
        contentValues.put(COL_WEIGHT_VALUE, weight);
        contentValues.put(COL_LOSS_GAIN_RATIO, lossGainRatio);
        contentValues.put(COL_GOAL_WEIGHT, goalWeight);
        long result = db.insert(TABLE_WEIGHT, null, contentValues);
        return result != -1; // Returns true if insertion was successful
    }

    // Update weight entry method
    public boolean updateWeightEntry(int id, String date, double weight, double lossGainRatio, double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_DATE, date);
        contentValues.put(COL_WEIGHT_VALUE, weight);
        contentValues.put(COL_LOSS_GAIN_RATIO, lossGainRatio);
        contentValues.put(COL_GOAL_WEIGHT, goalWeight);
        return db.update(TABLE_WEIGHT, contentValues, COL_WEIGHT_ID + " = ?", new String[]{String.valueOf(id)}) > 0;
    }

    // Delete weight entry method
    public boolean deleteWeightEntry(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        int result = db.delete(TABLE_WEIGHT, "id=?", new String[]{String.valueOf(id)});
        return result > 0; // Returns true if deletion was successful
    }
}